﻿namespace JardínInfantil
{
    partial class RegistroE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            comboBox1 = new ComboBox();
            cbce = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            tbrc = new TextBox();
            tbnombre = new TextBox();
            label4 = new Label();
            dateTimePicker1 = new DateTimePicker();
            tbbuscar = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(119, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(445, 143);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Autismo", "Hiperactividad", "Discapacidad" });
            comboBox1.Location = new Point(160, 207);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 1;
            // 
            // cbce
            // 
            cbce.FormattingEnabled = true;
            cbce.Items.AddRange(new object[] { "1", "2", "3", "4 ", "5", "6" });
            cbce.Location = new Point(159, 294);
            cbce.Name = "cbce";
            cbce.Size = new Size(121, 23);
            cbce.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 210);
            label1.Name = "label1";
            label1.Size = new Size(107, 15);
            label1.TabIndex = 3;
            label1.Text = "Condición especial";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 251);
            label2.Name = "label2";
            label2.Size = new Size(134, 15);
            label2.TabIndex = 4;
            label2.Text = "Número de registro civil";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 343);
            label3.Name = "label3";
            label3.Size = new Size(105, 15);
            label3.TabIndex = 5;
            label3.Text = "Nombre completo\r\n";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(10, 297);
            label5.Name = "label5";
            label5.Size = new Size(134, 15);
            label5.TabIndex = 7;
            label5.Text = "Estrato socioeconómico";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(262, 378);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(34, 19);
            radioButton1.TabIndex = 8;
            radioButton1.TabStop = true;
            radioButton1.Text = "Si";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(302, 378);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(41, 19);
            radioButton2.TabIndex = 9;
            radioButton2.TabStop = true;
            radioButton2.Text = "No";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 10;
            button1.Text = "Registrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(12, 71);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 11;
            button2.Text = "Consultar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(12, 127);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 12;
            button3.Text = "Eliminar registros";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // tbrc
            // 
            tbrc.Location = new Point(160, 251);
            tbrc.Name = "tbrc";
            tbrc.Size = new Size(120, 23);
            tbrc.TabIndex = 13;
            // 
            // tbnombre
            // 
            tbnombre.Location = new Point(159, 343);
            tbnombre.Name = "tbnombre";
            tbnombre.Size = new Size(121, 23);
            tbnombre.TabIndex = 14;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(159, 378);
            label4.Name = "label4";
            label4.Size = new Size(92, 15);
            label4.TabIndex = 15;
            label4.Text = "Requiere terapia";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(328, 269);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 16;
            // 
            // tbbuscar
            // 
            tbbuscar.Location = new Point(282, 161);
            tbbuscar.Name = "tbbuscar";
            tbbuscar.Size = new Size(100, 23);
            tbbuscar.TabIndex = 17;
            // 
            // RegistroE
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(579, 414);
            Controls.Add(tbbuscar);
            Controls.Add(dateTimePicker1);
            Controls.Add(label4);
            Controls.Add(tbnombre);
            Controls.Add(tbrc);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cbce);
            Controls.Add(comboBox1);
            Controls.Add(dataGridView1);
            DoubleBuffered = true;
            Name = "RegistroE";
            Text = "RegistroE";
            Load += RegistroE_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private ComboBox comboBox1;
        private ComboBox cbce;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox tbrc;
        private TextBox tbnombre;
        private Label label4;
        private DateTimePicker dateTimePicker1;
        private TextBox tbbuscar;
    }
}