﻿namespace EPS
{
    partial class Registro2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro2));
            dataGridView1 = new DataGridView();
            dateTimePicker1 = new DateTimePicker();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            tbid = new TextBox();
            tbedad = new TextBox();
            tbnombre = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            comboBox1 = new ComboBox();
            label4 = new Label();
            button4 = new Button();
            tbtiempo = new TextBox();
            label5 = new Label();
            tbregistro = new TextBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(7, 7);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(315, 154);
            dataGridView1.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(50, 167);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 1;
            // 
            // button1
            // 
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.BottomRight;
            button1.Location = new Point(26, 352);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 2;
            button1.Text = "Registrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.BottomRight;
            button2.Location = new Point(102, 352);
            button2.Name = "button2";
            button2.Size = new Size(123, 23);
            button2.TabIndex = 3;
            button2.Text = "Eliminar registro";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.BottomRight;
            button3.Location = new Point(226, 352);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 4;
            button3.Text = "Reporte";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // tbid
            // 
            tbid.Location = new Point(102, 238);
            tbid.Name = "tbid";
            tbid.Size = new Size(125, 23);
            tbid.TabIndex = 5;
            // 
            // tbedad
            // 
            tbedad.Location = new Point(102, 275);
            tbedad.Name = "tbedad";
            tbedad.Size = new Size(125, 23);
            tbedad.TabIndex = 6;
            tbedad.TextChanged += tbedad_TextChanged;
            // 
            // tbnombre
            // 
            tbnombre.Location = new Point(102, 200);
            tbnombre.Name = "tbnombre";
            tbnombre.Size = new Size(125, 23);
            tbnombre.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Image = (Image)resources.GetObject("label1.Image");
            label1.ImageAlign = ContentAlignment.BottomRight;
            label1.Location = new Point(15, 202);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 8;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.ImageAlign = ContentAlignment.BottomRight;
            label2.Location = new Point(2, 241);
            label2.Name = "label2";
            label2.Size = new Size(79, 15);
            label2.TabIndex = 9;
            label2.Text = "Identificación";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Image = (Image)resources.GetObject("label3.Image");
            label3.ImageAlign = ContentAlignment.BottomRight;
            label3.Location = new Point(21, 283);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 10;
            label3.Text = "Edad";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Prioritaria", "General", "Urgencia" });
            comboBox1.Location = new Point(102, 313);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(125, 23);
            comboBox1.TabIndex = 12;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Image = (Image)resources.GetObject("label4.Image");
            label4.ImageAlign = ContentAlignment.BottomRight;
            label4.Location = new Point(2, 319);
            label4.Name = "label4";
            label4.Size = new Size(94, 15);
            label4.TabIndex = 13;
            label4.Text = "Tipo de consulta";
            // 
            // button4
            // 
            button4.BackColor = Color.Coral;
            button4.BackgroundImageLayout = ImageLayout.Center;
            button4.ImageAlign = ContentAlignment.BottomRight;
            button4.Location = new Point(322, 274);
            button4.Name = "button4";
            button4.Size = new Size(97, 28);
            button4.TabIndex = 14;
            button4.Text = "Tiempo espera";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // tbtiempo
            // 
            tbtiempo.Enabled = false;
            tbtiempo.Location = new Point(334, 308);
            tbtiempo.Name = "tbtiempo";
            tbtiempo.Size = new Size(28, 23);
            tbtiempo.TabIndex = 15;
            tbtiempo.TextAlign = HorizontalAlignment.Center;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.LightSalmon;
            label5.ImageAlign = ContentAlignment.BottomRight;
            label5.Location = new Point(367, 312);
            label5.Name = "label5";
            label5.Size = new Size(51, 15);
            label5.TabIndex = 16;
            label5.Text = "Minutos";
            // 
            // tbregistro
            // 
            tbregistro.Location = new Point(328, 23);
            tbregistro.Name = "tbregistro";
            tbregistro.Size = new Size(100, 23);
            tbregistro.TabIndex = 17;
            tbregistro.TextAlign = HorizontalAlignment.Center;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Image = (Image)resources.GetObject("label6.Image");
            label6.ImageAlign = ContentAlignment.BottomRight;
            label6.Location = new Point(337, 5);
            label6.Name = "label6";
            label6.Size = new Size(83, 15);
            label6.TabIndex = 18;
            label6.Text = "Total Registros";
            // 
            // Registro2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(440, 378);
            Controls.Add(label6);
            Controls.Add(tbregistro);
            Controls.Add(label5);
            Controls.Add(tbtiempo);
            Controls.Add(button4);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tbnombre);
            Controls.Add(tbedad);
            Controls.Add(tbid);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dateTimePicker1);
            Controls.Add(dataGridView1);
            Name = "Registro2";
            Text = "Registro2";
            Load += Registro2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DateTimePicker dateTimePicker1;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox tbid;
        private TextBox tbedad;
        private TextBox tbnombre;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox comboBox1;
        private Label label4;
        private Button button4;
        private TextBox tbtiempo;
        private Label label5;
        private TextBox tbregistro;
        private Label label6;
    }
}