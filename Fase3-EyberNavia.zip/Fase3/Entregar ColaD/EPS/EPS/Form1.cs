namespace EPS
{
    public partial class Form1 : Form
    {
      
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           if (pass.Text == "123")
            {
                Registro2 form = new Registro2();
                pass.Text = "";
                form.Show();
            }
            else
            {
                    MessageBox.Show("Por favor dijite la contrase�a");
                    pass.Text ="";
                    pass.Focus();
                   
                  
                 
            }
        }
    }
}