﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EPS
{
    public partial class Registro2 : Form
    {

        Queue<ColaEPS> mycolaeps = new Queue<ColaEPS>();

        public Registro2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColaEPS mycola = new ColaEPS();
            mycola.identificacion = tbid.Text;
            mycola.Nombre = tbnombre.Text;
            mycola.edad = tbedad.Text;
            mycola.Fecha = dateTimePicker1.Text;
            mycola.Consultar = comboBox1.Text;
            mycola.TiempoMinutos = tbtiempo.Text;
            mycolaeps.Enqueue(mycola);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = mycolaeps.ToList();
            //tbnombre.Clear();
            //tbid.Clear();
            //tbedad.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int op = 0;
            int edad = 0;
            if (edad >=0 && edad <=10)
            {
                
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String consultar = comboBox1.SelectedItem.ToString();
            int tep = 0;
            int teu = 0;
            int teg = 0;
           

            if (consultar == "Prioritaria") 
            {
                tep = tep + 10;
                tbtiempo.Text = tep.ToString();
            }
            if (consultar == "General")
            {
                teg = tep + 20;
                tbtiempo.Text = teg.ToString();
            }
            if (consultar == "Urgencia")
            {
                teu = tep + 5;
                tbtiempo.Text = teu.ToString();

            }

        }

        private void Registro2_Load(object sender, EventArgs e)
        {

        }

        private void tbedad_TextChanged(object sender, EventArgs e)
        {
            
            int edad = 60;
            int tep = 0;
            int teu = 0;
            int teg = 0;
            string consulta;
            

            if (edad >=0 && edad <=10 )
            {
               consulta = "Prioritaria";
               tep = tep + 10;
               tbtiempo.Text = tep.ToString();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            tbregistro.Text = mycolaeps.Count.ToString();
        }
    }
}
