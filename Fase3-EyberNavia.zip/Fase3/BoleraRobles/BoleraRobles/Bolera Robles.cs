﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BoleraRobles
{
    public partial class Bolera_Robles : Form
    {
        public Bolera_Robles()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pass.Text == "123")
            {

                BoleraR form = new BoleraR();
                pass.Text = "";
                form.Show();
            }

            else
            {
                MessageBox.Show("Contraseña incorrecta");
                pass.Text = "";
                pass.Focus();


            }


        }
    }
}
