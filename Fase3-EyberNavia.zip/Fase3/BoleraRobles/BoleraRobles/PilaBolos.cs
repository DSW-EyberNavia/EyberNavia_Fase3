﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace BoleraRobles
{
    public class PilaBolos
    {
        public string Nombre { get; set; }
       
        public string Idjugador { get; set; }
        public string Dirección { get; set; }
        public string Pista { get; set; }       
        
        public string Fecha { get; set; }

        public string Totalreserva { get; set; }


    }
}

