﻿namespace BoleraRobles
{
    partial class Bolera_Robles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bolera_Robles));
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            pass = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(104, 154);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "INGRESAR";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaptionText;
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(-3, 203);
            label1.Name = "label1";
            label1.Size = new Size(145, 15);
            label1.TabIndex = 1;
            label1.Text = "Eyber Arley Navia Guevara";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(94, 48);
            label2.Name = "label2";
            label2.Size = new Size(94, 15);
            label2.TabIndex = 2;
            label2.Text = "BOLERA ROBLES";
            // 
            // pass
            // 
            pass.Location = new Point(88, 125);
            pass.Name = "pass";
            pass.PasswordChar = '*';
            pass.Size = new Size(100, 23);
            pass.TabIndex = 3;
            // 
            // Bolera_Robles
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(284, 219);
            Controls.Add(pass);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Bolera_Robles";
            Text = "Bolera_Robles";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label2;
        private TextBox pass;
    }
}